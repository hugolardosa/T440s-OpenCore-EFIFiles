Driver Mac OS X para Teclado Windows USB Português
Copyright (C) 2012 Magnum Ingenium

Este setup instala o teclado Windows USB Português no Mac.

Author: Laurentino Martins
Website: www.magnumingenium.com